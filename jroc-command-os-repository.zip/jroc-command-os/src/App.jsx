import {
  ChevronDown,
  Crown,
  Headphones,
  MessageSquare,
  Mic,
  Send,
  Zap,
} from 'lucide-react';
import { agents, appIcons, metrics, missionLog, navItems, suggestedActions } from './data/dashboardData.js';
import './styles/app.css';

const { Gauge } = appIcons;

function Sidebar() {
  return (
    <aside className="sidebar">
      <div className="brand-block">
        <div className="logo-mark">JR</div>
        <div>
          <h1>J-ROC</h1>
          <p>AI Command Center</p>
        </div>
      </div>

      <nav className="navigation">
        {navItems.map(({ label, icon: Icon, active }) => (
          <button className={`nav-item ${active ? 'active' : ''}`} key={label}>
            <Icon size={21} />
            <span>{label}</span>
            {label === 'AI Assistant' && <ChevronDown size={16} className="nav-chevron" />}
          </button>
        ))}
      </nav>

      <section className="system-status card compact-card">
        <div className="card-header">
          <h3>System Status</h3>
          <ChevronDown size={16} />
        </div>
        <p className="online-dot">All systems operational</p>
        <div className="mini-line-chart" aria-label="system performance chart">
          <span style={{ height: '34%' }} />
          <span style={{ height: '58%' }} />
          <span style={{ height: '42%' }} />
          <span style={{ height: '72%' }} />
          <span style={{ height: '48%' }} />
          <span style={{ height: '64%' }} />
          <span style={{ height: '38%' }} />
          <span style={{ height: '82%' }} />
        </div>
        <div className="status-footer">
          <span>Uptime</span>
          <strong>99.7%</strong>
        </div>
      </section>
    </aside>
  );
}

function HeroPanel() {
  return (
    <section className="hero-panel card neon-frame">
      <div className="avatar-stage">
        <div className="avatar-glow" />
        <div className="avatar-card">
          <div className="avatar-placeholder">J</div>
          <div className="avatar-plaque">
            <h2>J-ROC</h2>
            <p>AI Commander</p>
          </div>
        </div>
      </div>
      <blockquote>“I don’t just answer. I execute.”</blockquote>
    </section>
  );
}

function AssistantPanel() {
  return (
    <aside className="assistant-panel card neon-frame">
      <div className="panel-title">
        <div className="title-left"><Headphones size={20} /><h2>AI Assistant</h2></div>
        <span className="pill online">Online</span>
      </div>

      <div className="chat-bubble-row">
        <div className="mini-avatar">J</div>
        <div className="chat-bubble">
          <strong>What’s the mission today, Boss?</strong>
          <span>I’m ready to build, create, and dominate. Let’s run it.</span>
        </div>
      </div>

      <div className="suggested-actions">
        <h3>Suggested Actions</h3>
        {suggestedActions.map(({ label, icon: Icon }) => (
          <button key={label}>
            <Icon size={19} />
            <span>{label}</span>
          </button>
        ))}
      </div>

      <div className="command-input">
        <input placeholder="Type your command..." />
        <button aria-label="send command"><Send size={24} /></button>
      </div>
      <div className="voice-mode"><Mic size={18} /> Voice Mode <span /></div>
    </aside>
  );
}

function SystemOverview() {
  return (
    <section className="card widget">
      <div className="card-header"><h3>System Overview</h3><ChevronDown size={16} /></div>
      <div className="overview-body">
        <div className="donut"><span>92%</span><small>Total Performance</small></div>
        <ul>
          {metrics.map((metric) => <li key={metric.label}><span>{metric.label}</span><strong>{metric.value}</strong></li>)}
        </ul>
      </div>
    </section>
  );
}

function RevenueTracker() {
  return (
    <section className="card widget revenue-widget">
      <div className="card-header"><h3>Revenue Tracker</h3><span>This Month</span></div>
      <div className="revenue-number">$24,780 <small>+32.4% vs last month</small></div>
      <div className="revenue-chart">
        {[22, 28, 20, 34, 39, 48, 42, 66, 71, 58, 44, 53, 49, 62, 56, 70, 74].map((height, index) => (
          <span key={index} style={{ height: `${height}%` }} />
        ))}
      </div>
    </section>
  );
}

function AgentsPanel() {
  return (
    <section className="card widget agents-widget">
      <div className="card-header"><h3>Active AI Agents</h3><ChevronDown size={16} /></div>
      {agents.map((agent) => (
        <div className="agent-row" key={agent.name}>
          <div className="agent-icon"><Zap size={17} /></div>
          <div><strong>{agent.name}</strong><span>{agent.specialty}</span></div>
          <em>{agent.status}</em>
        </div>
      ))}
    </section>
  );
}

function MissionLog() {
  return (
    <section className="card widget mission-widget">
      <div className="card-header"><h3>Mission Log</h3><a href="#">View All</a></div>
      {missionLog.map((item) => (
        <div className="mission-row" key={`${item.time}-${item.event}`}>
          <time>{item.time}</time>
          <span className="pulse" />
          <p><strong>{item.event}</strong><small>{item.agent}</small></p>
        </div>
      ))}
    </section>
  );
}

function App() {
  return (
    <main className="app-shell">
      <Sidebar />
      <section className="main-area">
        <header className="top-header">
          <div className="eyebrow">AI Assistant</div>
          <h1>J-ROC Command AI</h1>
          <p>“Your Vision. My Execution.”</p>
          <div className="profile-chip"><div className="profile-avatar">J</div><div><strong>J-ROC <Crown size={15} /></strong><span>Founder / CEO</span></div><ChevronDown size={18} /></div>
        </header>

        <section className="dashboard-grid">
          <HeroPanel />
          <AssistantPanel />
          <SystemOverview />
          <RevenueTracker />
          <AgentsPanel />
          <MissionLog />
        </section>

        <footer className="footer-bar">
          <div className="footer-logo">J-ROC</div>
          <p>“Technology is the engine. Vision is the fuel. Execution is the difference.”</p>
          <div className="signature">J-ROC</div>
          <div className="time-block">10:45 AM <span>Monday, May 27, 2024</span></div>
        </footer>
      </section>
    </main>
  );
}

export default App;
