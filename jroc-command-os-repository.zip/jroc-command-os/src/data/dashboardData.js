import {
  BarChart3,
  Bot,
  BriefcaseBusiness,
  Database,
  Gauge,
  Home,
  Music,
  Settings,
  Shield,
  ShoppingCart,
  Sparkles,
  Workflow,
  PenTool,
  Mic,
  Send,
  TrendingUp,
} from 'lucide-react';

export const navItems = [
  { label: 'Dashboard', icon: Home, active: true },
  { label: 'AI Assistant', icon: Bot },
  { label: 'Music Studio', icon: Music },
  { label: 'Business AI', icon: BriefcaseBusiness },
  { label: 'Automation', icon: Workflow },
  { label: 'Agent Swarm', icon: Sparkles },
  { label: 'Data Vault', icon: Shield },
  { label: 'Marketplace', icon: ShoppingCart },
  { label: 'Analytics', icon: BarChart3 },
  { label: 'Settings', icon: Settings },
];

export const suggestedActions = [
  { label: 'Generate New Music', icon: Music },
  { label: 'Write Business Plan', icon: BriefcaseBusiness },
  { label: 'Create Social Media Content', icon: PenTool },
  { label: 'Run Automation Workflow', icon: Workflow },
  { label: 'Analyze Revenue Data', icon: TrendingUp },
];

export const agents = [
  { name: 'CEO Agent', specialty: 'Strategic Decisions', status: 'Online' },
  { name: 'Writer Agent', specialty: 'Content Creation', status: 'Online' },
  { name: 'Music Agent', specialty: 'Music & Lyrics', status: 'Online' },
  { name: 'Ops Agent', specialty: 'Automation & Tasks', status: 'Online' },
  { name: 'Sales Agent', specialty: 'Leads & Revenue', status: 'Online' },
];

export const missionLog = [
  { time: '10:45 AM', event: 'Generated 3 New Song Concepts', agent: 'Music Agent' },
  { time: '10:30 AM', event: 'Business Plan Draft Completed', agent: 'CEO Agent' },
  { time: '10:15 AM', event: 'Social Media Content Scheduled', agent: 'Ops Agent' },
  { time: '09:50 AM', event: 'Automation Workflow Executed', agent: 'Automation Agent' },
  { time: '09:30 AM', event: 'Revenue Report Generated', agent: 'Analytics Agent' },
];

export const metrics = [
  { label: 'AI Agents', value: '24' },
  { label: 'Automations', value: '18' },
  { label: 'Tasks Completed', value: '347' },
  { label: 'Data Processed', value: '1.2TB' },
];

export const appIcons = { Gauge, Database, Mic, Send };
