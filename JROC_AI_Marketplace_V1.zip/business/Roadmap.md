Phase 1 Launch
Phase 2 Scale
Phase 3 Marketplace.