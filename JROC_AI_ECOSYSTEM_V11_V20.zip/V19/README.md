JROC Ecosystem Version 19
