JROC Ecosystem Version 12
