JROC Ecosystem Version 14
