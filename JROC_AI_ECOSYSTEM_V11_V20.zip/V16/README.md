JROC Ecosystem Version 16
