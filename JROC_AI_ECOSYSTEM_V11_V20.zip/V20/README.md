JROC Ecosystem Version 20
