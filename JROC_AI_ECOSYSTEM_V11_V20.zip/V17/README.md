JROC Ecosystem Version 17
