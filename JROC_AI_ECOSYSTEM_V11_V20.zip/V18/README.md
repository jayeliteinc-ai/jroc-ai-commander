JROC Ecosystem Version 18
